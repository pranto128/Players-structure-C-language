#include<stdio.h>
#include<stdlib.h>
#include <string.h>
struct player_info
{
    int id;
    char country[20];
    char player_name[20];
    int age;
    int joining_year;
    double height;
    char position[20];
    int total_goals;
    int jersey_no;
    int total_match_played;
    char address[30];
    char performance[20]; //good, outdoor, better, best etc.
    double monthly_income; //in US dollar.

};

int main()

{
    int i;
    printf("Enter the information of the players :\n");
    struct player_info s[50];
    File *fp;
    fp=fopen("player.txt","r");

    for(int i=0;i<50;i++)
        {

        fscanf(fp,"%d%[^-]-%[^-]-%d%d%lf%[^-]-%d%d%d%[^-]-%[^-]-%lf", &s[i].country,&s[i].player_name, &s[i].age, &s[i].joining_year,&s[i].height,&s[i].position,&s[i].total_goals, &s[i].Jursey_no, &s[i].total_mach_played, &s[i].address, &s[i].performance, &s[i].monthly_income);

        }



       for(int i=0;i<50;i++)
    {
        printf("%d\n",s[i].id);
        puts(s[i].country);
        puts(s[i].player_name);
        printf("%d\n",s[i].age);
        printf("%d",s[i].joining_year);
        printf("%.2lf\n"s[i].height);
        puts(s[i].position);
        printf("%d\n",s[i].total_goals);
        printf("%d\n",s[i].jersey_no);
        printf("%d\n",s[i].total_match_played);
        puts(s[i].address);
        puts(s[i].performance);
        printf("%.2lf\n",s[i].monthly_income);
    }



  /*
    char a[20];
    int counter=0;
    //int country;
    printf ("which country?\n");
    gets(a);
    for(int i=0; i<50;i++){
        if(strcmp(a,n[i].country)==0){
            puts(n[i].name);
            counter++;
        }
    }
    printf("%d players are from %s\n",counter,a);
  */




  /*
    double min=n[0].height;
    for(int i=0;i<50;i++){
        if(n[i].height<min){
            min=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=0;i<50;i++){
        if(n[i].height==min){
            puts(n[i].name);
        }
    }
  */



/*
    double min=n[0].height;
    for(int i=1;i<11;i++){
        if(n[i].height<min){
            min=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=1;i<11;i++){
        if(n[i].height==min){
            puts(n[i].name);
        }
    }
*/



  /*
    double min=n[0].height;
    for(int i=12;i<22;i++){
        if(n[i].height<min){
            min=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=12;i<22;i++){
        if(n[i].height==min){
            puts(n[i].name);
        }
    }
  */



   /*
    double min=n[0].height;
    for(int i=34;i<44;i++){
        if(n[i].height<min){
            min=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=34;i<44;i++){
        if(n[i].height==min){
            puts(n[i].name);
        }
    }
  */




  /*
    double max=n[0].height;
    for(int i=0;i<50;i++){
        if(n[i].height>max){
            max=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=0;i<50;i++){
        if(n[i].height==max){
            puts(n[i].name);
        }
    }
  */




   /*
    double max=n[0].height;
    for(int i=1;i<11;i++){
        if(n[i].height>max){
            max=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=1;i<11;i++){
        if(n[i].height==max){
            puts(n[i].name);
        }
    }
  */




  /*
    double max=n[0].height;
    for(int i=12;i<22;i++){
        if(n[i].height>max){
            max=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=12;i<22;i++){
        if(n[i].height==max){
            puts(n[i].name);
        }
    }
  */




  /*
    double max=n[0].height;
    for(int i=23;i<33;i++){
        if(n[i].height>max){
            max=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=23;i<33;i++){
        if(n[i].height==max){
            puts(n[i].name);
        }
    }
 */




  /*
    double max=n[0].height;
    for(int i=34;i<44;i++){
        if(n[i].height>max){
            max=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=34;i<44;i++){
        if(n[i].height==max){
            puts(n[i].name);
        }
    }
  */




  /*
    double max=n[0].height;
    for(int i=45;i<50;i++){
        if(n[i].height>max){
            max=n[i].height;
        }
    }

    printf("the shortest players are :\n");

    for(i=45;i<50;i++){
        if(n[i].height==max){
            puts(n[i].name);
        }
    }
  */





   /*
     int min=n[0].age;
     for(int i=0;i<50;i++){
        if(n[i].age<min){
            min=n[i].age;
        }
    }

    printf("the junior players are :\n");

    for(i=0;i<50;i++){
        if(n[i].age==min){
            puts(n[i].name);
        }
    }
   */




   /*
     int min=n[0].age;
     for(int i=1;i<11;i++){
        if(n[i].age<min){
            min=n[i].age;
        }
    }

    printf("the junior players are :\n");

    for(i=1;i<11;i++){
        if(n[i].age==min){
            puts(n[i].name);
        }
    }

  */



    /*
     int min=n[0].age;
     for(int i=12;i<22;i++){
        if(n[i].age<min){
            min=n[i].age;
        }
    }

    printf("the junior players are :\n");

    for(i=12;i<22;i++){
        if(n[i].age==min){
            puts(n[i].name);
        }
    }
  */



   /*
     int min=n[0].age;
     for(int i=23;i<33;i++){
        if(n[i].age<min){
            min=n[i].age;
        }
    }

    printf("the junior players are :\n");

    for(i=23;i<33;i++){
        if(n[i].age==min){
            puts(n[i].name);
        }
    }
  */



   /*
     int min=n[0].age;
     for(int i=34;i<44;i++){
        if(n[i].age<min){
            min=n[i].age;
        }
    }

    printf("the junior players are :\n");

    for(i=34;i<44;i++){
        if(n[i].age==min){
            puts(n[i].name);
        }
    }
  */



   /*
     int min=n[0].age;
     for(int i=45;i<50;i++){
        if(n[i].age<min){
            min=n[i].age;
        }
    }

    printf("the junior players are :\n");

    for(i=45;i<50;i++){
        if(n[i].age==min){
            puts(n[i].name);
        }
    }
   */




  /*
    int max=n[0].age;
    for(int i=0;i<50;i++){
        if(n[i].age>max){
            max=n[i].age;
        }
    }

    printf("the senior players are :\n");

    for(i=0;i<50;i++){
        if(n[i].age==max){
            puts(n[i].name);
        }
    }
  */




  /*
    int max=n[0].age;
    for(int i=1;i<11;i++){
        if(n[i].age>max){
            max=n[i].age;
        }
    }

    printf("the senior players are :\n");

    for(i=1;i<11;i++){
        if(n[i].age==max){
            puts(n[i].name);
        }
    }
  */




 /*
    int max=n[0].age;
    for(int i=12;i<22;i++){
        if(n[i].age>max){
            max=n[i].age;
        }
    }

    printf("the senior players are :\n");

    for(i=12;i<22;i++){
        if(n[i].age==max){
            puts(n[i].name);
        }
    }
 */




/*
    int max=n[0].age;
    for(int i=23;i<33;i++){
        if(n[i].age>max){
            max=n[i].age;
        }
    }

    printf("the senior players are :\n");

    for(i=23;i<33;i++){
        if(n[i].age==max){
            puts(n[i].name);
        }
    }
 */




/*
    int max=n[0].age;
    for(int i=34;i<44;i++){
        if(n[i].age>max){
            max=n[i].age;
        }
    }

    printf("the senior players are :\n");

    for(i=34;i<44;i++){
        if(n[i].age==max){
            puts(n[i].name);
        }
    }
 */




  /*
    int max=n[0].age;
    for(int i=45;i<50;i++){
        if(n[i].age>max){
            max=n[i].age;
        }
    }

    printf("the senior players are :\n");

    for(i=45;i<50;i++){
        if(n[i].age==max){
            puts(n[i].name);
        }
    }
  */





   /*
    int max=n[0].goals;
    for(int i=0;i<50;i++){
        if(n[i].goals>max){
            max=n[i].goals;
        }
    }

    printf("most goals players are :\n");

    for(i=0;i<50;i++){
        if(n[i].goals==max){
            puts(n[i].name);
        }
    }
   */



   /*
    int min=n[0].goals;
    for(int i=0;i<50;i++){
        if(n[i].goals<min){
            min=n[i].goals;
        }
    }

    printf("lowest goals players are :\n");

    for(i=0;i<50;i++){
        if(n[i].goals==min){
            puts(n[i].name);
        }
    }
  */


   fclose(fp);
    return 0;



}










